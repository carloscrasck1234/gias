#include <iostream>
using namespace std;

int main() {

    float min, costotal;
    cout<<"Ingrese el tiempo de uso por minuto del telefono: ";
    cin>>min;
    
    min>0;
    
	if (min>0 && min<3)
		costotal=0.5;
	else
		costotal=0.5+(min-3)*0.1;
	
	cout<<"El monto total por uso del telefono es de s/."<<costotal;
		
    return 0;
}
