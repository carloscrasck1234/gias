#include<iostream>

using namespace std;

int main (){
	
	int SaldoA, mont,SaldoN;
	char mov;
	cout<<"ingresa el saldo actual: ";cin>>SaldoA;
	cout<<"Escriba el tipo de movimiento, Deposito(D) o Retiro(R): ";cin>>mov;
	cout<<"Ingrese el monto a mover: ";cin>>mont;
	
	if (mov=='D'){
			SaldoN=SaldoA+mont;
	}
		else if (mov=='R'){
			SaldoN=SaldoA-mont;
	}
		else {

		cout<<"escriba la letra correcta";
		return 0;
	}
	cout<<"El saldo nuevo es "<<SaldoN<<endl;
	
	return 0;
	
}