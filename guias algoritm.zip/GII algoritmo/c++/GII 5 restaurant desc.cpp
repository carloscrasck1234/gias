#include <iostream>
using namespace std;

int main() {
	
    double consumo, descuento, impuesto, total;
    float imp, desc10, desc20;
    cout<<"Ingrese el valor del consumo: ";
    cin>>consumo;
    
    imp=0.19;
    desc10=0.1;
    desc20=0.2;
    // Calcular el descuento y el impuesto según el valor del consumo
    if (consumo<=100){
        descuento=consumo*desc10;
    } else {
        descuento=consumo*desc20;
    }
    impuesto=(consumo-descuento)*imp;
    
    // Calcular el total a pagar
    total=consumo-descuento+impuesto;
    
    // Mostrar los resultados
    cout<<"Descuento: " <<descuento<<endl;
    cout<<"Impuesto: " <<impuesto<<endl;
    cout<<"Total a pagar: "<<total<<endl;
    
    return 0;
}
