#include <iostream>
using namespace std;

int main() {

    int L, area;
    cout<<"Ingrese el lado: ";
    cin>>L;

	area=L*L;
	if (area>0 && area<100)
	
		cout<<"El area es "<< area<<" y es cuadrado pequenio";
		
    return 0;
}
