#include <iostream>
using namespace std;

int main() {
    float sueldoA, aumento, sueldoFin;
    cout << "Ingrese el salario del empleado: ";
    cin >> sueldoA;

    if (sueldoA <= 800) {
        aumento = sueldoA *0.2;
    } else if (sueldoA <= 1000) {
        aumento = (sueldoA * 0.1);
    } else if (sueldoA <= 1500) {
        aumento = (sueldoA * 0.05);
    } else if (sueldoA > 1500) {
        aumento = sueldoA * 0;
    }

    sueldoFin = sueldoA + aumento;
    cout<<"El nuevo sueldo del empleado es: " << sueldoFin << endl;
    
    return 0;
}
