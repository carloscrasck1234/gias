#include <iostream>
using namespace std;

int main() {
    float ventas, comision, total;
    
    cout << "Ingrese cuantas ventas hizo el empleado: ";
    cin >> ventas;

    if (ventas <= 200) {
        comision = 0;
    } else if (ventas <= 1000) {
        comision = (ventas * 0.1);
    } else if (ventas <= 2000) {
        comision = (ventas * 0.15);
    } else if (ventas <= 3000) {
        comision = ventas * 0.20;
    } else if (ventas <= 4000) {
        comision = ventas * 0.25;
    } else if (ventas > 4000) {
        comision = ventas * 0.30;
    }

    total = ventas + comision;
    cout << "El monto total mas la comision es: " << total << endl;
    return 0;
}
