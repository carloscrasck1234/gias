#include<iostream>
#include <conio.h> 

using namespace std;
int main(){
	int notat,notam,notaf;
	float prom = 0;
	
	cout<<"ingrese la nota de trabajo 50% : ";cin>>notat;
	cout<<"Ingrese la nota del ciclo mdedio 20% : ";cin>>notam;
	cout<<"Ingrese la nota final 30%: ";cin>>notaf;
	
	notat = notat*0.5;
	notam = notam*0.2;
	notaf = notaf*0.3;
	prom = notat + notam + notaf;

	if(prom <= 20 && prom >= 16){
		cout<<" PROMEDIO BUENO "<<endl;
	}else if(prom <= 15 && prom >= 11){
		cout<<" PROMEDIO REGULAR "<<endl;
	}else  if(prom <= 10 && prom >= 6){
		cout<<" PROMEDIO MALO "<<endl;
	}else{
		cout<<" PROMEDIO PESIMO "<<endl;
	}
	 
	cout<<"El promedio es "<<prom;
	
	return 0;
}