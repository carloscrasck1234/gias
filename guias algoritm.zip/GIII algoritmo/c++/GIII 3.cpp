#include <iostream>

using namespace std;

int main() {
    int num1, num2, num3, num4, num5, maxnum;
    cout << "Ingrese cinco numeros: ";
    cin >> num1 >> num2 >> num3 >> num4 >> num5;

    maxnum = num1;
    
    if (num2 > maxnum) {
        maxnum = num2;
    }
    if (num3 > maxnum) {
        maxnum = num3;
    }
    if (num4 > maxnum) {
        maxnum = num4;
    }
    if (num5 > maxnum) {
        maxnum = num5;
    }

    cout<<"El numero mayor es: "<<maxnum <<endl;
   
    return 0;
}
