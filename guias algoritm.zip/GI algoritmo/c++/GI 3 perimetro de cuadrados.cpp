#include<iostream>
#include<math.h>

using namespace std;

int main (){
	double a, Per ;
	
	cout<<"ingreese el lado; ";
	cin>>a;
	
	
	Per=4*a*(2+sqrt(2));
	
	cout<<"el perimetro es "<<Per;
	
	return 0;
}