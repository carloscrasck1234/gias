#include<iostream>

using namespace std;

int main (){
	int cant, bill100,bill50,bill10, mon1, resto;
	
	cout<<"ingrese la cantidad en soles ";
	cin>>cant;
	
	bill100=cant / 100;
	resto=cant % 100;
	bill50=resto / 50;
	resto=resto % 50;
	bill10=resto / 10;
	resto=resto % 10;
	mon1=resto;
	
	cout<<"hay "<<bill100<<" billetes de 100 "<<endl;
	cout<<"Hay "<<bill50<<" billetes de 50 soles "<<endl;
	cout<<"Hay "<<bill10<<" billetes de 10 soles "<<endl;
	cout<<"Hay "<<mon1<<" monedas de 1 sol"<<endl;
	
	return 0;
}