#include <iostream>
using namespace std;

int main() {

    float sBruto, desct, sNeto, mQuincena, mFinDeMes;
    
    cout<<"Ingrese el salario bruto: ";
    cin>>sBruto;
    

    desct =sBruto * 0.12;
    

    sNeto =sBruto - desct;
    

    mQuincena =sNeto * 0.4;
    

    mFinDeMes=sNeto - mQuincena;
    

    cout<<"Sueldo neto: " << sNeto << endl;
    cout<<"Monto en la quincena: " << mQuincena << endl;
    cout<<"Monto en el fin de mes: " <<mFinDeMes << endl;
    