#include <iostream>

using namespace std;

int main(){
	int Gsexag,Gcent,Gradian;
	cout<<"Ingrese en grados sexagesimal: ";
	cin>>Gsexag;
	
	Gcent=(Gsexag*200)/180;
	Gradian=(Gsexag*3.14)/180;
	
	cout<<"En centesimal es "<<Gcent<<endl;
	cout<<"En radian es "<<Gradian<<endl;
	
	return 0;
	
}