#include <iostream>

using namespace std;

int main(){
	int Nper,Apmano;
	
	cout<<"escriba el numero de personas: ";
	cin>>Nper;
	
	Apmano=Nper*(Nper-1)/2;
	
	cout<<"El total de apretones que hubo son "<<Apmano;
	
}